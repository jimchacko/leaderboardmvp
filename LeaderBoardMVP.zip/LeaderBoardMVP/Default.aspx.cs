﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LeaderBoardMVP
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string welcomeUrl = "LoginPage.aspx";

            OpenWindow(welcomeUrl);

        }
        private void OpenWindow(string url)
        {
           
            {
                Response.Redirect(url, true);
            }
        }
    }
}