﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LeaderBoardMVP
{
    public partial class LoginPage : PageBase
    {

        protected void Page_Load(object sender, EventArgs e)
        {
        }
        protected void btnLogin_Click(object sender, EventArgs e)
        {
            DoLogin();

        }
        private void DoLogin()
        {
            try
            {
                ConncetionDbase();

                //Login Click
                cmd = new OleDbCommand("select accType  from  UserAccount where login = @login and Password =@password");
                cmd.Connection = conn;

                string welcomeUrl = "";
                if (conn.State == ConnectionState.Open)
                {
                    cmd.Parameters.Add("@login", OleDbType.VarChar).Value = txtLoginName.Text;
                    cmd.Parameters.Add("@password", OleDbType.VarChar).Value = txtPassword.Text.Trim();

                    reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            string acounttype = (reader.GetString(0));

                            if (acounttype.Equals("Admin", StringComparison.CurrentCultureIgnoreCase))
                            {
                                welcomeUrl = "WelcomePage.aspx";

                            }
                            else if (acounttype.Equals("Guest", StringComparison.CurrentCultureIgnoreCase))
                                welcomeUrl = "LeaderBoard.aspx";
                            else
                            {
                                Page.ClientScript.RegisterStartupScript(this.GetType(), "ErrorAlert", "alert('The user  is not registered as Admin/Guest');", true);
                            }

                        }
                    }
                    else
                    {
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "ErrorAlert", "alert('The user name/Password is not matching');", true);

                    }
                }
                if (welcomeUrl.Trim().Length > 0)
                    OpenWindow(welcomeUrl);

            }
            catch (Exception ex)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "ErrorAlert", "alert('Error in Login');", true);

            }
            finally
            {
                conn.Close();
            }

        }
        /// <summary>
        /// Redirect the page
        /// </summary>
        /// <param name="url"></param>
        private void OpenWindow(string url)
        {

            {
                Response.Redirect(url, true);
            }
        }
    }
}