﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Web;

namespace LeaderBoardMVP
{
    public partial class PageBase : System.Web.UI.Page
    {
        protected OleDbCommand cmd = null;
        protected OleDbConnection conn = null;
        protected OleDbDataReader reader;
        protected void ConncetionDbase()
        {
            conn = new OleDbConnection();
            conn.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\\LeaderBoardMVP.mdb;Persist Security Info=False";
            conn.Open();
        }

    }
}