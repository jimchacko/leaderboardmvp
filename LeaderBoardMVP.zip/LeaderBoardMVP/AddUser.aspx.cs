﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LeaderBoardMVP
{

    public partial class AddUser : PageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
        protected void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                ConncetionDbase();

                //Add new competitor
                cmd = new OleDbCommand("INSERT INTO competitor (CName,cAddress) VALUES (@comName,@cAddress)");
                cmd.Connection = conn;
                if (conn.State == ConnectionState.Open)
                {
                    cmd.Parameters.Add("@comName", OleDbType.VarChar).Value = txtName.Text;
                    cmd.Parameters.Add("@cAddress", OleDbType.VarChar).Value = txtAddress.Text.Trim();

                    try
                    {
                        cmd.ExecuteNonQuery();

                    }
                    catch (OleDbException ex)
                    {
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "ErrorAlert", "alert('Error in Adding User');", true);

                    }

                    Response.Redirect(Request.RawUrl);
                }

            }
            catch (Exception ex)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "ErrorAlert", "alert('Something went wrong in adding user');", true);
            }
            finally
            {
                conn.Close();
            }
        }
    }
}