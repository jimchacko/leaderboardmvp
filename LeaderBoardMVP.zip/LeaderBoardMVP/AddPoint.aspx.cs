﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.DataVisualization.Charting;
using System.Web.UI.WebControls;

namespace LeaderBoardMVP
{
    public partial class AddPoint : PageBase
    {
        //    OleDbCommand cmd = null;
        //    string connectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\\LeaderBoardMVP.mdb;Persist Security Info=False";

        //    OleDbConnection conn = null;


        List<string> competitors = null;


        enum matchStatus : int { Complete = 1, Ongoing, notstarted };
        //  enum winnerPoint : int { loss = 0, draw = 1, win = 3 };
        protected void Page_Load(object sender, EventArgs e)
        {
            ConncetionDbase();

            // conn = new OleDbConnection(connectionString);

            //  conn.Open();
            cmd = new OleDbCommand("select distinct cname from  competitor");
            cmd.Connection = conn;
            if (conn.State == ConnectionState.Open)
            {
                reader = cmd.ExecuteReader();
                if (reader != null)
                {
                    competitors = new List<string>();
                }
                while (reader.Read())
                {
                    competitors.Add(reader.GetString(0));
                }
            }
            conn.Close();
            if (competitors.Count > 0)
            {
                for (int i = 0; i < competitors.Count; i++)
                {
                    DropDownTeam1.Items.Add(competitors[i]);
                    DropDownTeam2.Items.Add(competitors[i]);
                }
            }
            reader.Close();

            //cmd = new OleDbCommand("select teamname, sum(teamPoint)  from ScoreTable group by teamname order bysum(teamPoint) ");

            //if (conn.State == ConnectionState.Closed)
            //    conn.Open();
            //cmd.Connection = conn;

            //if (conn.State == ConnectionState.Open)
            //{
            //    reader = cmd.ExecuteReader();
            //    if (reader.HasRows)
            //    {

            //    }
            //    while (reader.Read())
            //    {
            //        competitors.Add(reader.GetString(0));
            //    }
            //}
            //conn.Close();

        }



        protected void btnAddPoint_Click(object sender, EventArgs e)
        {

            string team1 = DropDownTeam1.Text;
            string team2 = DropDownTeam2.Text;
            int team1Point = Team1Point.Text.Trim().Length == 0 ? 0 : int.Parse(Team1Point.Text);
            int team2Point = Team2Point.Text.Trim().Length == 0 ? 0 : int.Parse(Team2Point.Text);

            if (team1.Equals(team2))
            {
                lblStatus.Text = "Both Teams are equal, please check the team names";
                return;
            }

            if (conn.State == ConnectionState.Closed)
                conn.Open();

            cmd = new OleDbCommand("INSERT INTO Game (C1,C2,CStatus,C1Point,C2Point) VALUES (@c1Name,@c2Name,@cStatus,@C1Point,@C2Point)");

            // cmd = new OleDbCommand("INSERT INTO Game (C1,C2) VALUES ('@c1Name','@c2Name')");

            cmd.Connection = conn;

            if (conn.State == ConnectionState.Open)
            {
                cmd.Parameters.Add("@c1Name", OleDbType.VarWChar).Value = team1;
                cmd.Parameters.Add("@c2Name", OleDbType.VarWChar).Value = team2;
                cmd.Parameters.Add("@cStatus", OleDbType.Integer).Value = matchStatus.Complete;
                cmd.Parameters.Add("@C1Point", OleDbType.Integer).Value = team1Point;
                cmd.Parameters.Add("@C2Point", OleDbType.Integer).Value = team2Point;

                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (OleDbException ex)
                {
                    // MessageBox.Show(ex.Source);
                    conn.Close();
                    lblStatus.Text = "Error in updating the result " + ex.ToString();
                }
            }
            //Going to update the Point table for the players
            try
            {


                cmd = new OleDbCommand("INSERT INTO scoretable (TeamName,TeamPoint) VALUES (@TeamName,@TeamPoint)");
                cmd.Parameters.Clear();

                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.Connection = conn;
                if (conn.State == ConnectionState.Open)
                {
                    cmd.Parameters.Add("@TeamName", OleDbType.VarWChar).Value = team1;
                    cmd.Parameters.Add("@TeamPoint", OleDbType.VarWChar).Value = team1Point;

                    try
                    {
                        cmd.ExecuteNonQuery();
                        cmd.Parameters.Clear();
                        cmd.Parameters.Add("@TeamName", OleDbType.VarWChar).Value = team2;
                        cmd.Parameters.Add("@TeamPoint", OleDbType.VarWChar).Value = team2Point;
                        cmd.ExecuteNonQuery();
                    }

                    catch (OleDbException ex)
                    {
                                              lblStatus.Text = "Error in updating the score card " + ex.ToString();
                    }
                }

            }
            catch (OleDbException ex)
            {
                lblStatus.Text = "Error in updating the DataBase for  player point " + ex.ToString();
            }
            finally
            {
                conn.Close();
                lblStatus.Text = "Game result updated";

        

                Response.Redirect(Request.RawUrl);
            }
            
        }
    }

}